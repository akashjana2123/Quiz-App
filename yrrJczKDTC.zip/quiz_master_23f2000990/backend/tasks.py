import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from io import StringIO
from datetime import datetime
from celery_config import celery
from model import db, User, Score, Quiz
import csv
from app import app


@celery.task
def send_daily_reminder():
    with app.app_context():
        users = User.query.all()
        today = datetime.utcnow().date()
        
        for user in users:
            last_quiz_attempt = Score.query.filter_by(user_id=user.id).order_by(Score.time_stamp_of_attempt.desc()).first()
            latest_quiz = Quiz.query.order_by(Quiz.date_of_quiz.desc()).first()
            
            should_remind = not last_quiz_attempt or last_quiz_attempt.time_stamp_of_attempt.date() != today
            # if latest_quiz and latest_quiz.date_of_quiz.date() == today:
            if latest_quiz and latest_quiz.date_of_quiz == today:
                should_remind = True
            
            if should_remind:
                html_content = f"""
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Daily Quiz Reminder</title>
                </head>
                <body>
                    <h3>Hello {user.username},</h3>
                    <p>You have a pending quiz to attempt. Don't forget to check it out today!</p>
                    <p><a href="http://localhost:5000/quizzes">Go to Quizzes</a></p>
                    <p>Best Regards,<br>Quiz Master</p>
                </body>
                </html>
                """
                send_email(user.email, "Daily Quiz Reminder", html_content)

@celery.task
def send_monthly_report():
    with app.app_context():
        current_month = datetime.now().strftime('%B')
        current_year = datetime.now().year

        users = User.query.all()

        for user in users:
            scores = Score.query.filter(
                Score.user_id == user.id,
                Score.time_stamp_of_attempt >= datetime(datetime.now().year, datetime.now().month, 1)
            ).all()

            total_quizzes = len(scores)
            total_score = sum(score.total_scored for score in scores)
            average_score = total_score / total_quizzes if total_quizzes > 0 else 0

            html_content = f"""
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Monthly Activity Report</title>
            </head>
            <body>
                <h3>Monthly Report - {current_month} {current_year}</h3>
                <p>Hello {user.username},</p>
                <p>Here's your activity summary for this month:</p>
                <ul>
                    <li>Total Quizzes Attempted: {total_quizzes}</li>
                    <li>Total Score: {total_score}</li>
                    <li>Average Score: {average_score:.2f}</li>
                </ul>
                <p>Keep up the great work!</p>
                <p>Best Regards,<br>Quiz Master</p>
            </body>
            </html>
            """
            send_email(user.email, "Monthly Activity Report", html_content)

def send_email(to_email, subject, html_content,attachment=None):
    from_email = 'QUIZMASTER@gmail.com'
    msg = MIMEMultipart('alternative')
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    
    part1 = MIMEText(html_content, 'html')
    msg.attach(part1)
    
    if attachment:
        from email.mime.application import MIMEApplication
        from email.mime.base import MIMEBase
        from email import encoders
        
        with open(attachment, 'rb') as file:
            # Use MIMEApplication for CSV files
            part = MIMEApplication(file.read(), Name=os.path.basename(attachment))
            
        # Add header with filename
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment)}"'
        msg.attach(part)
        
    smtp_server = 'localhost'
    smtp_port = 1025
    
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.sendmail(from_email, to_email, msg.as_string())



@celery.task
def export_quiz_details_as_csv(user_id):


    """Export completed quizzes for a specific user asynchronously."""

    with app.app_context():
        user = User.query.get(user_id)
        if not user:
            return f"User with ID {user_id} not found"

        # Create a CSV buffer
        csv_buffer = StringIO()
        csv_writer = csv.writer(csv_buffer)

        # Write CSV headers
        csv_writer.writerow(['Quiz ID', 'Date of Quiz', 'Score', 'Remarks'])

        # Fetch user's completed quizzes
        scores = Score.query.filter_by(user_id=user_id).all()
        
        for score in scores:
            quiz = Quiz.query.get(score.quiz_id)
            csv_writer.writerow([
                score.quiz_id,
                quiz.date_of_quiz.strftime("%Y-%m-%d"),  # Format date properly
                score.total_scored,
                quiz.remarks if quiz.remarks else "No remarks"
            ])

        # Define file path
        base_dir = os.path.abspath(os.path.dirname(__file__))
        # os.makedirs(os.path.join(base_dir, 'exports'), exist_ok=True)
        # csv_file_path = os.path.join(base_dir, 'exports', f'quiz_report_{user_id}.csv')
        csv_dir = os.path.join(base_dir, 'csv')
        os.makedirs(csv_dir, exist_ok=True)
        csv_file_path = os.path.join(csv_dir, 'data.csv')


        # Save CSV file
        with open(csv_file_path, 'w', newline='') as csv_file:
            csv_file.write(csv_buffer.getvalue())


        # Send email notification with attachment
        if user.email:
            subject = "Your Quiz Export is Ready"
            html_content = f"""
            <p>Hello {user.username},</p>
            <p>Your quiz export has been completed successfully. Click the link below to download your report:</p>
            <p><a href="http://localhost:5000/download/{user_id}">Download Report</a></p>
            <p>Best Regards,<br>Quiz Master Team</p>
            """
            send_email(user.email, subject, html_content, attachment=csv_file_path)

        # return csv_file_path  # Returning file path for API response
        return csv_buffer.getvalue()

