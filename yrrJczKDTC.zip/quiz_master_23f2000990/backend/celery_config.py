from celery import Celery
from celery.schedules import crontab
# import tasks
from flask import current_app as app



celery = Celery(
    __name__, 
    broker='redis://localhost:6379/0',
    backend='redis://localhost:6379/0'
)


# Auto-discover tasks from the 'tasks' module
# celery.autodiscover_tasks(['tasks'])

CELERY_BEAT_SCHEDULE = {
    'generate_monthly_schedule': {
        'task': 'tasks.send_monthly_report',
        'schedule': 100.0  # Change to crontab(day_of_month=1, hour=0, minute=0) for production
    },
    'daily-reminders': {
        'task': 'tasks.send_daily_reminder',
        'schedule': 100.0  # Change to crontab(hour=18, minute=0) for production
    }
}

celery.conf.beat_schedule = CELERY_BEAT_SCHEDULE


# Terminal0:
# source myenv/bin/activate
# cd backend
# python3 app.py

# Terminal1:
# redis-server

# Terminal2:
# MailHog

# Terminal3:
# source myenv/bin/activate
# cd backend
# celery -A celery_config worker --loglevel=info

# Terminal4:
# source myenv/bin/activate
# cd backend
# celery -A celery_config beat --loglevel=info