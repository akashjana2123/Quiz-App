from flask import Flask, jsonify, make_response, request, send_file
from flask_restful import Api, Resource, reqparse
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, unset_jwt_cookies
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from model import db, User, Subject, Chapter, Quiz, Question, Score, quiz_question_association
from datetime import date, datetime
from sqlalchemy import func
from flask_jwt_extended import verify_jwt_in_request,decode_token
from functools import wraps
from flask_caching import Cache
from celery.result import AsyncResult
import redis


app = Flask(__name__)
redis_client = redis.Redis(host='localhost',port=6379,db=0)
cache = Cache(app,config={
    'CACHE_TYPE':'redis',
    'CACHE_REDIS':redis_client
}) 



app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///quiz_master.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'quiz_secret_key'

db.init_app(app)
CORS(app, origins='*')
jwt = JWTManager(app)
api = Api(app)



@app.before_request
def log_request_info():
    print(f"Headers: {request.headers}")
    print(f"Body: {request.get_data()}")

    auth_header = request.headers.get("Authorization", None)
    if auth_header:
        token = auth_header.replace("Bearer ", "")
        try:
            decoded = decode_token(token)
            print(f"Decoded Token: {decoded}")
        except Exception as e:
            print(f"Invalid token: {e}")


class DecodeTokenResource(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('token', type=str, required=True)
        args = parser.parse_args()

        try:
            decoded = decode_token(args['token'])
            return jsonify(decoded)
        except Exception as e:
            return {"message": str(e)}, 400

api.add_resource(DecodeTokenResource, '/api/decode-token')
# Admin and User Authentication Endpoints
class SignupResource(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('username', type=str, required=True)
        parser.add_argument('email', type=str, required=True)
        parser.add_argument('password', type=str, required=True)
        parser.add_argument('full_name', type=str, required=True)
        parser.add_argument('role', type=str, choices=['student', 'admin'], default='student')
        parser.add_argument('qualification', type=str)
        parser.add_argument('dob', type=str)
        args = parser.parse_args()

        if User.query.filter_by(username=args['username']).first():
            return {"message": "Username already exists"}, 400
        
        try:
            dob = date.fromisoformat(args['dob']) if args['dob'] else None
        except ValueError:
            return {"message": "Invalid date format. Use YYYY-MM-DD."}, 400

        hashed_password = generate_password_hash(args['password'])
        if args['role'] =='student':
            new_user = User(
                username=args['username'],
                password=hashed_password,
                email=args['email'],
                role=args['role'],
                full_name=args['full_name'],
                qualification=args['qualification'],
                dob=dob,
                approved=True
            )
        else:
            new_user = User(
                username=args['username'],
                password=hashed_password,
                email=args['email'],
                role=args['role'],
                full_name=args['full_name'],
                qualification=args['qualification'],
                dob=dob,
                approved=False
            )
        try:
            db.session.add(new_user)
            db.session.commit()
            return {"message": "User Created Successfully"}, 200
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500

api.add_resource(SignupResource, '/api/signup')

class LoginResource(Resource):
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('username', type=str, required=True)
        parser.add_argument('password', type=str, required=True)


        args = parser.parse_args()

        user = User.query.filter_by(username=args['username']).first()
        
        if user and check_password_hash(user.password, args['password']):
            if user.approved==False:
                return {'message':'Please wait for approval from the admin'}, 401
            access_token = create_access_token(identity=user.role)
            user_info = {
                "id": user.id,
                "username": user.username,
                "role": user.role
            }
            return {'access_token': access_token, "user": user_info}, 200
        else:
            return {'message': "Invalid username or password"}, 401

api.add_resource(LoginResource, '/api/login')

class LogoutResource(Resource):
    @jwt_required()
    def post(self):
        role = get_jwt_identity()
        print(role)
        resp = {"message": "Logged out successfully"}
        unset_jwt_cookies(jsonify(resp))
        return resp, 200

api.add_resource(LogoutResource, '/api/logout')

class ApproveUserResource(Resource):
    @jwt_required()
    def post(self):
        current_user_role = get_jwt_identity()
        if current_user_role != 'admin':
            return {"message": "Only admins can approve or disapprove users"}, 403

        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('approve', type=bool, required=True)
        args = parser.parse_args()

        user = User.query.get(args['user_id'])
        if not user:
            return {"message": "User not found"}, 404
        
        user.approved = args['approve']
        db.session.commit()

        status_message = "approved" if args['approve'] else "disapproved"
        return {"message": f"User {status_message} successfully"}, 200

api.add_resource(ApproveUserResource, '/api/approve-user')

# CRUD Operations for Subjects
class SubjectResource(Resource):
    @jwt_required()
    def get(self, subject_id=None):
        subjects = Subject.query.all()
        if subject_id:
            subject = Subject.query.get(subject_id)
            if not subject:
                return {"message": "Subject not found"}, 404
            return jsonify({
                "id": subject.id,
                "name": subject.name,
                "description": subject.description
            })

        subjects = Subject.query.all()
        return jsonify([{ 
            "id": s.id, 
            "name": s.name, 
            "description": s.description 
        } for s in subjects])

    @jwt_required()
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True)
        parser.add_argument('description', type=str, required=False)
        args = parser.parse_args()

        if Subject.query.filter_by(name=args['name']).first():
            return {"message": "Subject already exists"}, 400
        
        new_subject = Subject(name=args['name'], description=args['description'])
        db.session.add(new_subject)
        db.session.commit()

        return {"message": "Subject created successfully", "id": new_subject.id}, 201

    @jwt_required()
    def put(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', type=int, required=True)
        parser.add_argument('name', type=str, required=True)
        parser.add_argument('description', type=str, required=False)
        args = parser.parse_args()

        subject = Subject.query.get(args['id'])
        if not subject:
            return {"message": "Subject not found"}, 404
        
        subject.name = args['name']
        subject.description = args['description']
        db.session.commit()
        
        return {"message": "Subject updated successfully"}, 200

    @jwt_required()
    def delete(self, subject_id):
        subject = Subject.query.get(subject_id)
        if not subject:
            return {'message': 'Subject not found'}, 404
        
        db.session.delete(subject)
        db.session.commit()
        
        return {'message': 'Subject deleted successfully'}, 200

api.add_resource(SubjectResource, '/api/subject', '/api/subject/<int:subject_id>')


# CRUD Operations for Chapters
class ChapterResource(Resource):
    @jwt_required()
    def get(self):
        subject_id = request.args.get("subject_id")
        if not subject_id:
            return {"message": "Subject ID is required"}, 400
        chapters = Chapter.query.filter_by(subject_id=subject_id).all()
        return [{"id": ch.id, "name": ch.name, "description": ch.description} for ch in chapters], 200


    @jwt_required()
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True, help="Chapter name is required")
        parser.add_argument('description', type=str, required=False)
        parser.add_argument('subject_id', type=int, required=True, help="Subject ID is required")
        args = parser.parse_args()

        # Check if the subject exists
        if not Subject.query.get(args['subject_id']):
            return {"message": "Invalid subject_id. Subject not found."}, 400

        # Check if the chapter already exists for the subject
        if Chapter.query.filter_by(name=args['name'], subject_id=args['subject_id']).first():
            return {"message": "Chapter with this name already exists for this subject"}, 400

        # Create and save the new chapter
        new_chapter = Chapter(
            name=args['name'], 
            description=args['description'] or "", 
            subject_id=args['subject_id']
        )
        db.session.add(new_chapter)
        db.session.commit()

        return {"message": "Chapter created successfully", "id": new_chapter.id}, 201



    @jwt_required()
    def put(self, chapter_id):
        data = request.get_json()
        chapter = Chapter.query.get(chapter_id)
        if not chapter:
            return {"message": "Chapter not found"}, 404
        
        chapter.name = data.get("name", chapter.name)
        chapter.description = data.get("description", chapter.description)

        db.session.commit()
        return {"message": "Chapter updated successfully"}, 200

    @jwt_required()
    def delete(self, chapter_id):
        chapter = Chapter.query.get(chapter_id)
        if not chapter:
            return {"message": "Chapter not found"}, 404

        db.session.delete(chapter)
        db.session.commit()
        return {"message": "Chapter deleted successfully"}, 200

api.add_resource(ChapterResource, '/api/chapter', '/api/chapter/<int:chapter_id>')


# CRUD Operations for Questions
import logging
logging.basicConfig(level=logging.DEBUG)
class QuestionResource(Resource):
    @jwt_required()
    def get(self, question_id=None):  # Optional question_id
        try:
            if question_id:  # Fetch a single question by ID
                question = Question.query.get(question_id)
                if not question:
                    return {"message": "Question not found"}, 404
                return jsonify({
                    "id": question.id,
                    "question_statement": question.question_statement,
                    "option1": question.option1,
                    "option2": question.option2,
                    "option3": question.option3,
                    "option4": question.option4,
                    "correct_option": question.correct_option,
                    "chapter_id": question.chapter_id
                })

            # Fetch questions by chapter_id if provided, else fetch all questions
            chapter_id = request.args.get('chapter_id', type=int)
            if chapter_id:
                questions = Question.query.filter_by(chapter_id=chapter_id).all()
            else:
                questions = Question.query.all()  # Fetch all questions if no chapter_id is provided

            if not questions:
                return {"message": "No questions found"}, 404

            return jsonify([{
                "id": q.id,
                "question_statement": q.question_statement,
                "option1": q.option1,
                "option2": q.option2,
                "option3": q.option3,
                "option4": q.option4,
                "correct_option": q.correct_option,
                "chapter_id": q.chapter_id
            } for q in questions])

        except Exception as e:
            logging.error(f"Error fetching questions: {str(e)}", exc_info=True)
            return {"message": f"Internal Server Error: {str(e)}"}, 500

        
# http://127.0.0.1:5000/api/question?chapter_id=1   it gives all the questions associated with chapter with any id and her with 1
# http://127.0.0.1:5000/api/question/1   it gives the question with id 1 meaning 1 question will arrive at a time
# http://127.0.0.1:5000/api/question   it gives all the questions

    @jwt_required()
    def post(self):
        try:
            parser = reqparse.RequestParser()
            parser.add_argument('question_statement', type=str, required=True)
            parser.add_argument('option1', type=str, required=True)
            parser.add_argument('option2', type=str, required=True)
            parser.add_argument('option3', type=str)
            parser.add_argument('option4', type=str)
            parser.add_argument('correct_option', type=str, required=True)
            parser.add_argument('chapter_id', type=int, required=True)
            args = parser.parse_args()

            if args['correct_option'] not in ['option1', 'option2', 'option3', 'option4']:
                return {"message": "Invalid correct_option. Must be one of option1, option2, option3, or option4."}, 400

            new_question = Question(
                question_statement=args['question_statement'],
                option1=args['option1'],
                option2=args['option2'],
                option3=args.get('option3'),
                option4=args.get('option4'),
                correct_option=args['correct_option'],
                chapter_id=args['chapter_id']
            )

            db.session.add(new_question)
            db.session.commit()
            return {"message": "Question created successfully"}, 201
        except Exception as e:
            logging.error(f"Error creating question: {str(e)}", exc_info=True)
            db.session.rollback()
            return {"message": f"Internal Server Error: {str(e)}"}, 500

    @jwt_required()
    def put(self, question_id):
        try:
            question = Question.query.get(question_id)
            if not question:
                return {"message": "Question not found"}, 404

            parser = reqparse.RequestParser()
            parser.add_argument('question_statement', type=str)
            parser.add_argument('option1', type=str)
            parser.add_argument('option2', type=str)
            parser.add_argument('option3', type=str)
            parser.add_argument('option4', type=str)
            parser.add_argument('correct_option', type=str)
            args = parser.parse_args()

            if args['correct_option'] and args['correct_option'] not in ['option1', 'option2', 'option3', 'option4']:
                return {"message": "Invalid correct_option. Must be one of option1, option2, option3, or option4."}, 400

            question.question_statement = args['question_statement'] or question.question_statement
            question.option1 = args['option1'] or question.option1
            question.option2 = args['option2'] or question.option2
            question.option3 = args['option3'] or question.option3
            question.option4 = args['option4'] or question.option4
            question.correct_option = args['correct_option'] or question.correct_option

            db.session.commit()
            return {"message": "Question updated successfully"}, 200
        except Exception as e:
            db.session.rollback()
            return {"message": str(e)}, 500

    @jwt_required()
    def delete(self, question_id):
        try:
            question = Question.query.get(question_id)
            if not question:
                return {"message": "Question not found"}, 404

            db.session.delete(question)
            db.session.commit()
            return {"message": "Question deleted successfully"}, 200
        except Exception as e:
            db.session.rollback()
            return {"message": str(e)}, 500

api.add_resource(QuestionResource, '/api/question', '/api/question/<int:question_id>')


class QuizResource(Resource):
    @jwt_required()
    def get(self):
        try:
            quizzes = Quiz.query.all()
            return jsonify([{
                "id": quiz.id,
                "name": quiz.name,
                "date_of_quiz": quiz.date_of_quiz.strftime("%Y-%m-%d"),
                "time_duration": quiz.time_duration,
                "remarks": quiz.remarks,
                "question_count": len(quiz.questions)  # Return the count of associated questions
            } for quiz in quizzes])
        except Exception as e:
            return {"error": str(e)}, 500

    @jwt_required()
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True)
        parser.add_argument('time_duration', type=int, required=True)
        parser.add_argument('date_of_quiz', type=str, required=True)
        parser.add_argument('remarks', type=str)
        parser.add_argument('questions', type=list, location='json')
        args = parser.parse_args()

        identity = get_jwt_identity()
        if identity != 'admin':
            return {"message": "Unauthorized"}, 403


        try:
            new_quiz = Quiz(
                name=args['name'],
                time_duration=args['time_duration'],
                date_of_quiz=datetime.strptime(args['date_of_quiz'], "%Y-%m-%d"),
                remarks=args.get('remarks')
            )
            db.session.add(new_quiz)
            db.session.flush()

            if args['questions']:
                new_quiz.questions = Question.query.filter(Question.id.in_(args['questions'])).all()

            db.session.commit()
            return {"message": "Quiz created successfully", "quiz_id": new_quiz.id}, 201
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500

    @jwt_required()
    def put(self, quiz_id):
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str)
        parser.add_argument('time_duration', type=int)
        parser.add_argument('date_of_quiz', type=str)
        parser.add_argument('remarks', type=str)
        parser.add_argument('questions', type=list, location='json')
        args = parser.parse_args()

        identity = get_jwt_identity()
        if identity != 'admin':
            return {"message": "Only admins can update quizzes"}, 403

        try:
            quiz = Quiz.query.get(quiz_id)
            if not quiz:
                return {"message": "Quiz not found"}, 404

            if args['name']:
                quiz.name = args['name']
            if args['time_duration']:
                quiz.time_duration = args['time_duration']
            if args['date_of_quiz']:
                quiz.date_of_quiz = datetime.strptime(args['date_of_quiz'], "%Y-%m-%d")
            if args['remarks']:
                quiz.remarks = args['remarks']
            if args['questions']:
                quiz.questions = Question.query.filter(Question.id.in_(args['questions'])).all()

            db.session.commit()
            return {"message": "Quiz updated successfully"}
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500

    @jwt_required()
    def delete(self, quiz_id):
        identity = get_jwt_identity()
        if identity != 'admin':
            return {"message": "Only admins can delete quizzes"}, 403

        try:
            quiz = Quiz.query.get(quiz_id)
            if not quiz:
                return {"message": "Quiz not found"}, 404

            db.session.delete(quiz)
            db.session.commit()
            return {"message": "Quiz deleted successfully"}
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500

api.add_resource(QuizResource, '/api/quiz', '/api/quiz/<int:quiz_id>')


class SubmitQuizResource(Resource):
    @jwt_required()
    def post(self, quiz_id=None):  # quiz_id is optional here
        # If quiz_id is not provided in the URL, you can raise an error or handle it differently
        if quiz_id is None:
            return {"message": "Quiz ID is required"}, 400
        
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('answers', type=dict, required=True)  # {question_id: selected_option}
        args = parser.parse_args()

        # Use the quiz_id from the URL to fetch the quiz
        quiz = Quiz.query.get(quiz_id)
        if not quiz:
            return {"message": "Quiz not found"}, 404

        total_score = 0
        correct_answers = {}

        # Fetch correct answers from DB
        # You need to join or use a relation here, to fetch all the questions for the given quiz_id
        questions = db.session.query(Question).join(quiz_question_association).filter(quiz_question_association.c.quiz_id == quiz_id).all()

        for question in questions:
            correct_answers[question.id] = question.correct_option

        # Calculate score
        for question_id, selected_option in args['answers'].items():
            question_id = int(question_id)  # Ensure it's treated as an integer

            if question_id in correct_answers:
                # Check if the selected option matches the correct option
                if correct_answers[question_id] == selected_option:
                    total_score += 1

        # Save Score
        new_score = Score(user_id=args['user_id'], quiz_id=quiz_id, total_scored=total_score)
        db.session.add(new_score)
        try:
            db.session.commit()
            return {"message": "Quiz submitted successfully", "total_score": total_score}, 200
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500
    @jwt_required()
    def put(self, quiz_id=None):  # quiz_id is required here
        if quiz_id is None:
            return {"message": "Quiz ID is required"}, 400

        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('answers', type=dict, required=True)  # {question_id: selected_option}
        args = parser.parse_args()

        # Use the quiz_id from the URL to fetch the quiz
        quiz = Quiz.query.get(quiz_id)
        if not quiz:
            return {"message": "Quiz not found"}, 404

        total_score = 0
        correct_answers = {}

        # Fetch correct answers from DB
        questions = db.session.query(Question).join(quiz_question_association).filter(quiz_question_association.c.quiz_id == quiz_id).all()

        for question in questions:
            correct_answers[question.id] = question.correct_option

        # Calculate score
        for question_id, selected_option in args['answers'].items():
            question_id = int(question_id)  # Ensure it's treated as an integer
            if question_id in correct_answers:
                if correct_answers[question_id] == selected_option:
                    total_score += 1

        # Check if the student already submitted the quiz before
        existing_score = Score.query.filter_by(user_id=args['user_id'], quiz_id=quiz_id).first()

        if existing_score:
            # Update the existing score if it exists
            existing_score.total_scored = total_score
            db.session.commit()
            return {"message": "Quiz reattempted successfully", "total_score": total_score}, 200
        else:
            # Save the new score if no previous submission exists
            new_score = Score(user_id=args['user_id'], quiz_id=quiz_id, total_scored=total_score)
            db.session.add(new_score)
            try:
                db.session.commit()
                return {"message": "Quiz submitted successfully", "total_score": total_score}, 200
            except Exception as e:
                db.session.rollback()
                return {"error": str(e)}, 500

    @jwt_required()
    def delete(self, quiz_id=None):  # quiz_id is required here
        if quiz_id is None:
            return {"message": "Quiz ID is required"}, 400

        # Get the current user identity from JWT
        identity = get_jwt_identity()
        user_id = identity.get('user_id')  # Extract user_id from JWT

        # Find the existing score submission
        existing_score = Score.query.filter_by(user_id=user_id, quiz_id=quiz_id).first()

        if not existing_score:
            return {"message": "No submission found for this quiz"}, 404

        try:
            db.session.delete(existing_score)
            db.session.commit()
            return {"message": "Quiz submission deleted successfully"}, 200
        except Exception as e:
            db.session.rollback()
            return {"error": str(e)}, 500


api.add_resource(SubmitQuizResource, '/api/submitquiz', '/api/submitquiz/<int:quiz_id>')

class StudentQuizResource(Resource):
    @jwt_required()
    def get(self, quiz_id):
        try:
            quiz = Quiz.query.get(quiz_id)
            if not quiz:
                return {"message": "Quiz not found"}, 404

            # Get the questions associated with the quiz
            questions = db.session.query(Question).join(quiz_question_association).filter(quiz_question_association.c.quiz_id == quiz_id).all()

            # Returning quiz details including questions and their options
            return jsonify({
                "id": quiz.id,
                "name": quiz.name,
                "date_of_quiz": quiz.date_of_quiz.strftime("%Y-%m-%d"),
                "time_duration": quiz.time_duration,
                "remarks": quiz.remarks,
                "questions": [{
                    "id": q.id,
                    "question_statement": q.question_statement,
                    "option1": q.option1,
                    "option2": q.option2,
                    "option3": q.option3,
                    "option4": q.option4,
                    "correct_option": q.correct_option,
                    "chapter_id": q.chapter_id
                } for q in questions]
            })
        except Exception as e:
            return {"error": str(e)}, 500


api.add_resource(StudentQuizResource, '/api/student/quiz/<int:quiz_id>')


class ScoreResource(Resource):
    @jwt_required()
    def get(self):
        user_id = request.args.get('user_id', type=int)
        quiz_id = request.args.get('quiz_id', type=int)

        if not user_id:
            return {"message": "user_id is required."}, 400

        if quiz_id:
            # Fetch a specific score
            score = Score.query.filter_by(user_id=user_id, quiz_id=quiz_id).first()
            if not score:
                return {"message": "Score not found for the given quiz."}, 404

            return {"total_scored": score.total_scored}, 200

        else:
            # Fetch all scores for a user with quiz names
            scores = db.session.query(Score, Quiz.name).join(Quiz).filter(Score.user_id == user_id).all()

            if not scores:
                return {"message": "No scores found for this user."}, 404

            return {
                "scores": [
                    {"quiz_name": quiz_name, "total_scored": score.total_scored}
                    for score, quiz_name in scores
                ]
            }, 200

# Add the corrected route
#  http://127.0.0.1:5000/api/score?user_id=2&quiz_id=1   it will respond just the total scored value of the user in the quiz with id=1
# http://127.0.0.1:5000/api/score?user_id=2   it will respond all the scores of the user with id=2 with quiz names
api.add_resource(ScoreResource, '/api/score')


class AdminSummaryResource(Resource):
    def get(self):
        try:
            # Query to calculate total scores for each subject
            subject_scores = db.session.query(
                Subject.name.label('subject_name'),
                func.sum(Score.total_scored).label('total_score')
            ).join(Chapter).join(Question).join(quiz_question_association).join(Quiz).join(Score).group_by(Subject.id).all()

            # Query to calculate quiz attempts (number of users who attempted each quiz)
            quiz_attempts = db.session.query(
                Quiz.name.label('quiz_name'),
                func.count(Score.user_id).label('attempts')
            ).join(Score).group_by(Quiz.id).all()

            # Data for the bar chart (total scores per subject)
            bar_chart_data = {
                'labels': [item.subject_name for item in subject_scores],
                'data': [item.total_score if item.total_score else 0 for item in subject_scores]
            }

            # Data for the pie chart (quiz attempts)
            pie_chart_data = {
                'labels': [item.quiz_name for item in quiz_attempts],
                'data': [item.attempts for item in quiz_attempts]
            }

            # Returning the summary data in JSON format
            return jsonify({
                'bar_chart_data': bar_chart_data,
                'pie_chart_data': pie_chart_data
            })

        except Exception as e:
            logging.error(f"Error in AdminSummaryResource: {str(e)}")
            return {'message': f"An error occurred: {str(e)}"}, 500

# Register the resource
api.add_resource(AdminSummaryResource, '/api/admin/summary')


class StudentSummaryResource(Resource):
    def get(self):
        try:
            # Get the user_id from the request (assuming it's passed in as a query parameter)
            user_id = request.args.get('user_id')  # For example: /api/student/summary?user_id=1
            if not user_id:
                return {'message': 'User ID is required'}, 400

            # Query to get all quiz attempts by the student (marks obtained in each quiz)
            quiz_scores = db.session.query(
                Quiz.name.label('quiz_name'),
                Score.total_scored.label('marks_obtained')
            ).join(Score, Quiz.id == Score.quiz_id).filter(Score.user_id == user_id).all()

            # Data for the bar chart (marks obtained per quiz)
            bar_chart_data = {
                'labels': [item.quiz_name for item in quiz_scores],
                'data': [item.marks_obtained if item.marks_obtained else 0 for item in quiz_scores]
            }

            # Query to calculate the number of quiz attempts per month for the student
            monthly_attempts = db.session.query(
                func.strftime('%Y-%m', Score.time_stamp_of_attempt).label('month'),
                func.count(Score.id).label('attempts')
            ).filter(Score.user_id == user_id).group_by(func.strftime('%Y-%m', Score.time_stamp_of_attempt)).all()

            # Data for the pie chart (monthly quiz attempts)
            pie_chart_data = {
                'labels': [item.month for item in monthly_attempts],
                'data': [item.attempts for item in monthly_attempts]
            }

            # Returning the summary data in JSON format
            return jsonify({
                'bar_chart_data': bar_chart_data,
                'pie_chart_data': pie_chart_data
            })

        except Exception as e:
            logging.error(f"Error in StudentSummaryResource: {str(e)}")
            return {'message': f"An error occurred: {str(e)}"}, 500


# Register the resource
api.add_resource(StudentSummaryResource, '/api/student/summary')


class UserResource(Resource):
    @cache.cached(timeout=20)
    @jwt_required()
    def get(self):
        current_user_role = get_jwt_identity()
        if current_user_role != 'admin':
            return {"message": "Unauthorized. Only admins can view users."}, 403

        users = User.query.all()
        return jsonify([
            {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "role": user.role,
                "approved": user.approved
            } for user in users
        ])

api.add_resource(UserResource, '/api/users')

class ExportResource(Resource):
    #@jwt_required()
    def post(self, user_id):
        # user_role = get_jwt_identity()

        # Only admins can export CSV
        # if user_role != "admin":
        #     return jsonify({"message": "Access denied"}), 403

        try:
            from tasks import export_quiz_details_as_csv
            # Trigger Celery async task
            # tasks = export_quiz_details_as_csv.apply_async(args=[1])
            # return jsonify({"tasks_id": tasks.id, "message": "Export started"})

            csv_data = export_quiz_details_as_csv(user_id)

            response = make_response(csv_data)
            response.headers["Content-Disposition"] = "attachment; filename=data.csv"
            
            response.headers["Content-Type"] = "text/csv"
            return response

        except Exception as e:
            return make_response(jsonify({"error": str(e)}), 500)


class ExportStatusResource(Resource):
    def get(self, tasks_id):
        tasks = AsyncResult(tasks_id)
        if tasks.state == "PENDING":
            return jsonify({"status": "Processing"})
        elif tasks.state == "SUCCESS":
            return jsonify({"status": "Completed", "download_link": "/download_csv"})
        elif tasks.state == "FAILURE":
            return jsonify({"status": "Failed", "error": str(tasks.info)})
        else:
            return jsonify({"status": tasks.state})

# Register the API resources
api.add_resource(ExportResource, "/exportcsv", "/exportcsv/<int:user_id>")
api.add_resource(ExportStatusResource, "/export_status/<string:tasks_id>")



if __name__ == '__main__':
    app.run(debug=True)