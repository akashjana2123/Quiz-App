<template>
  <div>
    <AdminQuiz v-if="userRole === 'admin'" />
    <StudentQuiz v-else-if="userRole === 'student'" />
    <div v-else class="error-message">Invalid user role. Please contact support.</div>
  </div>
</template>

<script>
import AdminQuiz from '@/components/AdminQuiz.vue';
import StudentQuiz from '@/components/StudentQuiz.vue';

export default {
  components: {
    AdminQuiz,
    StudentQuiz,
  },
  data() {
    return {
      userRole: this.getUserRole(),
    };
  },
  methods: {
    getUserRole() {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        if (!user || !user.role) {
          throw new Error('User data is missing or invalid.');
        }
        return user.role;
      } catch (error) {
        console.error('Error fetching user role:', error.message);
        return null;
      }
    },
  },
};
</script>

<style scoped>
.error-message {
  color: red;
  font-weight: bold;
  margin-top: 20px;
}
</style>
