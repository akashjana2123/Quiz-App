<!-- UserSummary.vue -->
<template>
  <div>
    <AdminSummary v-if="userRole === 'admin'" />
    <StudentSummary v-else />
  </div>
</template>

<script>
import AdminSummary from '@/components/AdminSummary.vue';
import StudentSummary from '@/components/StudentSummary.vue';


export default {
  components: {
    AdminSummary,
    StudentSummary,
  },
  data() {
    return {
      userRole: JSON.parse(localStorage.getItem('user')).role,
    };
  },
};

</script>
