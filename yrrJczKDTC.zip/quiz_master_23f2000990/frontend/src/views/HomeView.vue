<template>
  <div>
    <NavbarComponent />
    <router-view />
  </div>
  <div class="home" style="text-align: center;">
    <img alt="Vue logo" src="../assets/logo.png" />
    <h1>Welcome to Quiz Master</h1>
    <!-- <HelloWorld msg="Welcome to Your Vue.js App" /> -->
  </div>
</template>

<script>
// @ is an alias to /src
import NavbarComponent from '@/components/NavbarComponent.vue';
// import HelloWorld from '@/components/HelloWorld.vue';

export default {
  name: 'HomeView',
  components: {
    NavbarComponent,
    // HelloWorld
  }
}
</script>
