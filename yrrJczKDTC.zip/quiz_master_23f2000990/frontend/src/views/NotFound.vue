<template>
    <div class="not-found-container">
        <h1>404 - Page Not Found</h1>
        <p>The page you're looking for doesn't exist.</p>
        <router-link to="/login" class="btn btn-primary">Go to Login</router-link>
    </div>
</template>

<script>
export default {
    created() {
        // When the 404 page loads, clear user session and redirect to login
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    }
};
</script>

<style scoped>
.not-found-container {
    text-align: center;
    margin-top: 10%;
}

h1 {
    font-size: 2.5rem;
    color: red;
}
</style>
