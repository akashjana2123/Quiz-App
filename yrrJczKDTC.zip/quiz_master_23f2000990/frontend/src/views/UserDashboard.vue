<!-- UserDashboard.vue -->
<template>
  <div>
    <AdminDashboard v-if="userRole === 'admin'" />
    <StudentDashboard v-else />
  </div>
</template>

<script>
import AdminDashboard from '@/components/AdminDashboard.vue';
import StudentDashboard from '@/components/StudentDashboard.vue';


export default {
  components: {
    AdminDashboard,
    StudentDashboard,
  },
  data() {
    return {
      userRole: JSON.parse(localStorage.getItem('user')).role,
    };
  },
};

</script>
