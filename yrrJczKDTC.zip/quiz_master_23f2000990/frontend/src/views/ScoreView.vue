<template>
  <div>
    <NavbarComponent title="Your Scores" />
    <div v-if="scores.length > 0">
      <h2 class="text-center text-2xl font-bold mt-5">Your Scores</h2>
      <div class="container mx-auto p-5">
        <div v-for="quiz in scores" :key="quiz.quiz_id" class="mb-4 p-4 border rounded-lg shadow-md bg-gray-100">
          <h3 class="font-bold">{{ quiz.quiz_name }}</h3>
          <button @click="toggleScore(quiz.quiz_id)" class="btn btn-primary mt-2 px-4 py-2 bg-blue-500 text-black rounded">
            {{ showScores[quiz.quiz_id] ? "Hide Score" : "Show Score" }}
          </button>
          <p v-if="showScores[quiz.quiz_id]" class="mt-2 font-bold text-lg">Score: {{ quiz.total_scored }}</p>
        </div>
      </div>
    </div>
    <div v-else>
      <p class="text-center mt-5">No scores found.</p>
    </div>
  </div>
</template>

<script>
import NavbarComponent from "@/components/NavbarComponent.vue";
import axios from "axios";



export default {
  components: {
    NavbarComponent,
  },
  data() {
    return {
      scores: [],
      showScores: {},
      userId: null,
    };
  },
  created() {
    this.fetchUserQuizzes();
  },
  methods: {
    async fetchUserQuizzes() {
      const token = localStorage.getItem("token");
      const user = JSON.parse(localStorage.getItem('user'));
      if(user){
        this.userId = user.id;
      }

      try {
        const response = await axios.get(`http://127.0.0.1:5000/api/score?user_id=${this.userId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        this.scores = response.data.scores.map((item, index) => ({
          quiz_id: index + 1, // Assuming backend does not return quiz_id, generating index-based IDs
          ...item
        }));
      } catch (error) {
        console.error("Error fetching quizzes:", error);
      }
    },

    toggleScore(quizId) {
      this.showScores[quizId] = !this.showScores[quizId];
    }
  }
};
</script>