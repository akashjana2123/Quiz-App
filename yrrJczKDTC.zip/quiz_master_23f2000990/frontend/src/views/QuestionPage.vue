<template>
  <div class="question-container">
    <header v-if="subject.name && chapter.name">
      <h2>Subject:</h2>
      <p>{{ subject.name }}</p>
      <p>{{ subject.description }}</p>

      <h2>Chapter:</h2>
      <p>{{ chapter.name }}</p>
      <p>{{ chapter.description }}</p>
    </header>
    <h5>Questions</h5>

    <button v-if="questions.length >= 0" class="btn btn-primary btn-sm mb-2" @click="showAddQuestionModal">
      Add Question
    </button>
    <!-- Save & Return Button -->
    <button class="btn btn-success mt-3" @click="saveAndReturn">Save & Return</button>

    <div v-if="questions.length > 0" class="table-responsive scrollable-table">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Question</th>
            <th>Options</th>
            <th>Correct Answer</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="question in questions" :key="question.id">
            <td>{{ question.id }}</td>
            <td>{{ question.question_statement }}</td>
            <td>
              <ul>
                <li>{{ question.option1 }}</li>
                <li>{{ question.option2 }}</li>
                <li v-if="question.option3">{{ question.option3 }}</li>
                <li v-if="question.option4">{{ question.option4 }}</li>
              </ul>
            </td>
            <td>{{ question[question.correct_option] }}</td>
            <td>
              <button class="btn btn-warning btn-sm" @click="editQuestion(question)">Edit</button>
              <button class="btn btn-danger btn-sm ml-2" @click="deleteQuestion(question.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Save & Return Button -->
    <button class="btn btn-success mt-3" @click="saveAndReturn">Save & Return</button>

    <!-- Question Modal -->
    <div v-if="showModal" class="modal-overlay">
      <div class="modal-content">
        <h4>{{ isEditing ? 'Edit' : 'Add' }} Question</h4>
        <input v-model="formData.question_statement" placeholder="Question Statement" class="form-control mb-2" />
        <input v-model="formData.option1" placeholder="Option 1" class="form-control mb-2" />
        <input v-model="formData.option2" placeholder="Option 2" class="form-control mb-2" />
        <input v-model="formData.option3" placeholder="Option 3" class="form-control mb-2" />
        <input v-model="formData.option4" placeholder="Option 4" class="form-control mb-2" />
        <select v-model="formData.correct_option" class="form-control mb-2">
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
          <option value="option4">Option 4</option>
        </select>
        <button class="btn btn-success" @click="saveQuestion">Save</button>
        <button class="btn btn-secondary ml-2" @click="showModal = false">Cancel</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      questions: [],
      showModal: false,
      isEditing: false,
      formData: this.getDefaultFormData(),
      subject: { name: "", description: "" },
      chapter: { name: "", description: "" },
      subjectId: this.$route.params.subjectId,  // Get from URL params
      chapterId: this.$route.params.chapterId,  // Get from URL params
    };
  },
  computed: {},
  async created() {
    await this.fetchDetails();  // Fetch both Subject & Chapter details
    await this.fetchQuestions();
  },
  methods: {
    getDefaultFormData() {
      return {
        question_statement: '',
        option1: '',
        option2: '',
        option3: '',
        option4: '',
        correct_option: 'option1',
        chapter_id: this.chapterId
      };
    },

    async fetchDetails() {
  try {
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };

    // Fetch Chapter Details
    const response = await axios.get(`http://localhost:5000/api/chapters/${this.chapterId}`, { headers });

    if (!response.data) throw new Error("No data received");

    // Manually trigger reactivity
    this.chapter = { 
      name: response.data.chapter_name || "Unknown Chapter", 
      description: response.data.chapter_description || "No description available" 
    };

    this.subjectId = response.data.subject_id;

    // Fetch Subject Details AFTER setting subjectId
    await this.fetchSubjectDetails();
  } catch (error) {
    console.error('Error fetching chapter details:', error.response ? error.response.data : error);
  }
},
    async fetchSubjectDetails() {
  try {
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };
    
    if (!this.subjectId) {
      console.error("Subject ID is undefined, skipping subject fetch.");
      return;
    }

    const response = await axios.get(`http://localhost:5000/api/subjects/${this.subjectId}`, { headers });

    if (!response.data) throw new Error("No subject data received");

    this.subject = { 
      name: response.data.subject_name || "Unknown Subject", 
      description: response.data.subject_description || "No description available" 
    };
  } catch (error) {
    console.error('Error fetching subject details:', error.response ? error.response.data : error);
  }
}
,

    async fetchQuestions() {
      try {
        console.log("Fetching questions for chapter:", this.chapterId);
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        const response = await axios.get(`http://localhost:5000/api/question?chapter_id=${this.chapterId}`, { headers });

        this.questions = response.data;
      } catch (error) {
        console.error('Error fetching questions:', error.response ? error.response.data : error);
      }
    },

    showAddQuestionModal() {
      this.isEditing = false;
      this.formData = this.getDefaultFormData();
      this.showModal = true;
    },

    editQuestion(question) {
      this.isEditing = true;
      this.formData = { ...question };
      this.showModal = true;
    },

    async saveQuestion() {
      try {
        const url = this.isEditing
          ? `http://localhost:5000/api/question/${this.formData.id}`
          : 'http://localhost:5000/api/question';

        const method = this.isEditing ? axios.put : axios.post;
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };

        await method(url, this.formData, { headers });
        this.showModal = false;
        this.fetchQuestions();
      } catch (error) {
        console.error('Error saving question:', error.response ? error.response.data : error);
      }
    },

    async deleteQuestion(id) {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        await axios.delete(`http://localhost:5000/api/question/${id}`, { headers });
        this.fetchQuestions();
      } catch (error) {
        console.error('Error deleting question:', error.response ? error.response.data : error);
      }
    },

    async saveAndReturn() {
      try {
        console.log("Saving all changes and returning to admin dashboard...");
        this.$router.push('/dashboard/admin'); // Redirect to admin dashboard
      } catch (error) {
        console.error("Error saving and returning:", error);
      }
    }
  }
};
</script>


<style scoped>
.scrollable-table {
  max-height: 300px;
  overflow-y: auto;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 5px;
  width: 400px;
}
</style>
