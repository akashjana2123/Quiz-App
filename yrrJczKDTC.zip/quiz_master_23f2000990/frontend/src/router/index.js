import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import UserSignup from "@/auth/UserSignup.vue";
import LoginUser from "@/auth/LoginUser.vue";
import UserDashboard from "@/views/UserDashboard.vue";
import NotFound from "@/views/NotFound.vue";
import QuizView from "@/views/QuizView.vue";
import SummaryView from "@/views/SummaryView.vue";
import ScoreView from "@/views/ScoreView.vue";
import QuestionPage from "@/views/QuestionPage.vue";

const routes = [
  { path: "/:catchAll(.*)", component: NotFound }, // Redirect unknown routes
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  {
    path: "/about",
    name: "about",
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
  },
  {
    path: "/signup",
    name: "UserSignup",
    component: UserSignup,
  },
  {
    path: "/login",
    name: "LoginUser",
    component: LoginUser,
  },
  {
    path: "/dashboard/:username",
    name: "UserDashboard",
    component: UserDashboard
  },
  {
    path: '/dashboard/:username/quiz/:quizId?',
    name: 'QuizView',
    component: QuizView
  },
  {
    path: "/dashboard/:username/score/:quizId?",
    name: "ScoreView",
    component: ScoreView
  },
  {
    path: "/dashboard/:username/summary/:userId?",
    name: "SummaryView",
    component: SummaryView
  },
  {
  path: '/dashboard/:username/questions/:chapterId',
  name: 'QuestionsPage',
  component: QuestionPage
  }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// Global Navigation Guard to ensure authentication
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user"));

  if (!token && to.path.startsWith("/dashboard")) {
    next("/login"); // Redirect to login if accessing dashboard without token
  } else if (token && to.path === "/login") {
    next(`/dashboard/${user?.username}`); // Redirect to dashboard if already logged in
  } else {
    next(); // Allow navigation
  }
});

export default router;