<template>
  <div>
    <NavbarComponent title="Quiz" />
    <div v-if="quiz">
      <h2 class="text-center text-2xl font-bold mt-5">{{ quiz.name }}</h2>
      <div class="text-center text-xl font-semibold text-red-600">Time Left: {{ formattedTime }}</div>
      <div class="container mx-auto p-5">
        <div v-if="questions && questions.length > 0">
          <form @submit.prevent="submitQuiz">
            <div v-for="(question, index) in questions" :key="question.id" class="mb-4">
              <h3 class="font-bold">{{ index + 1 }}. {{ question.question_statement }}</h3>
              <div>
                <label>
                  <input type="radio" v-model="answers[question.id]" :value="'option1'" />
                  {{ question.option1 }}
                </label>
              </div>
              <div>
                <label>
                  <input type="radio" v-model="answers[question.id]" :value="'option2'" />
                  {{ question.option2 }}
                </label>
              </div>
              <div v-if="question.option3">
                <label>
                  <input type="radio" v-model="answers[question.id]" :value="'option3'" />
                  {{ question.option3 }}
                </label>
              </div>
              <div v-if="question.option4">
                <label>
                  <input type="radio" v-model="answers[question.id]" :value="'option4'" />
                  {{ question.option4 }}
                </label>
              </div>
            </div>
            <button type="button" @click="submitQuiz"
              class="btn bg-gray-900 btn-success text-black px-4 py-2 rounded-lg shadow-lg border border-white hover:bg-gray-700 hover:border-gray-400 transition duration-300">
              Submit Now
            </button>
          </form>
        </div>
        <div v-else>
          <p>Loading questions...</p>
        </div>
      </div>
    </div>
    <div v-else>
      <p>Quiz data is not available.</p>
    </div>
  </div>
</template>

<script>
import NavbarComponent from "./NavbarComponent.vue";
import axios from "axios";

export default {
  components: {
    NavbarComponent,
  },
  data() {
    return {
      quizId: this.$route.params.quizId,
      quiz: null,
      questions: [],
      answers: {},
      timeLeft: 0, // Timer in seconds
      timer: null,
    };
  },
  computed: {
    formattedTime() {
      const minutes = Math.floor(this.timeLeft / 60);
      const seconds = this.timeLeft % 60;
      return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    },
  },
  created() {
    this.fetchQuizData();
  },
  methods: {
    async fetchQuizData() {
      try {
        const token = localStorage.getItem("token");
        const quizResponse = await axios.get(`http://localhost:5000/api/student/quiz/${this.quizId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        this.quiz = quizResponse.data;
        this.questions = this.quiz.questions;
        this.timeLeft = this.quiz.time_duration * 60; // Convert minutes to seconds
        this.startTimer();
      } catch (error) {
        console.error("Error fetching quiz data:", error);
      }
    },
    startTimer() {
      this.timer = setInterval(() => {
        if (this.timeLeft > 0) {
          this.timeLeft--;
        } else {
          clearInterval(this.timer);
          this.submitQuiz(); // Auto-submit when time is up
        }
      }, 1000);
    },
    async submitQuiz() {
      clearInterval(this.timer);
      const token = localStorage.getItem("token");
      const userId = JSON.parse(localStorage.getItem("user")).id;
      const username = JSON.parse(localStorage.getItem("user")).username;
      const quizId = this.quizId;
      try {
        const answers = {};
        this.questions.forEach((question) => {
          answers[question.id] = this.answers[question.id] || null;
        });
        await axios.post(
          `http://localhost:5000/api/submitquiz/${quizId}`,
          { user_id: userId, answers: answers },
          { headers: { Authorization: `Bearer ${token}` } }
        );
        this.$router.push(`/dashboard/${username}/score/${quizId}`);
      } catch (error) {
        console.error("Error submitting quiz:", error);
      }
    },
  },
  beforeUnmount() {
    console.log("Component is about to be destroyed");
  }
};
</script>

<style>
.text-red-600 {
  font-weight: bold;
}
</style>
