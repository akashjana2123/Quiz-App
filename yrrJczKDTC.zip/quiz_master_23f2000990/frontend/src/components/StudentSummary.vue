<template> 
  <div>
    <NavbarComponent title="Student Dashboard" />
    <h2>Student Summary</h2>

    <!-- Bar Chart for Marks per Quiz -->
    <div v-if="barChartData.labels.length > 0">
      <h3>Marks per Quiz</h3>
      <Bar :data="barChartData" />
    </div>

    <!-- Pie Chart for Monthly Quiz Attempts -->
    <div v-if="pieChartData.labels.length > 0">
      <h3>Monthly Quiz Attempts</h3>
      <Pie :data="pieChartData" />
    </div>
  </div>
</template>


<script>
import NavbarComponent from '@/components/NavbarComponent.vue';
import { Bar, Pie } from 'vue-chartjs'
import { Chart as ChartJS, Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale, ArcElement } from 'chart.js'
import axios from 'axios'

// Register necessary Chart.js components
ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale, ArcElement)

export default {
  components: {
    NavbarComponent,
    Bar,
    Pie
  },
  data() {
    return {
      barChartData: {
        labels: [],
        datasets: [{
          label: 'Marks Obtained',
          data: [],
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
        }],
      },
      pieChartData: {
        labels: [],
        datasets: [{
          data: [],
          backgroundColor: ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FFD433'],
        }],
      },
    };
  },
  mounted() {
    // Extract userId from the URL parameter
    const userId = this.$route.params.userId;
    if (userId) {
      this.fetchSummaryData(userId);  // Fetch the summary data using userId
    }
  },
  methods: {
    async fetchSummaryData(userId) {
      console.log('Fetching data for user:', userId);
  
      try {
        const apiUrl = `http://localhost:5000/api/student/summary?user_id=${userId}`;
        const response = await axios.get(apiUrl);
  
        const { bar_chart_data, pie_chart_data } = response.data;
  
        // Update Bar Chart Data
        this.barChartData.labels = bar_chart_data.labels;
        this.barChartData.datasets[0].data = bar_chart_data.data;
  
        // Update Pie Chart Data
        this.pieChartData.labels = pie_chart_data.labels;
        this.pieChartData.datasets[0].data = pie_chart_data.data;
      } catch (error) {
        console.error("Error fetching student summary data", error);
      }
    },
  },
}
</script>


<style scoped>
/* Styling for the charts */
canvas {
  max-width: 600px;
  margin: 20px auto;
}

button {
  padding: 10px 20px;
  margin: 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}
</style>
