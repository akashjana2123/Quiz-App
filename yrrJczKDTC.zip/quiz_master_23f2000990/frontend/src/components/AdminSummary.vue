<template>
  <div>
    <NavbarComponent title="Admin Dashboard" />
    <h2>Admin Summary</h2>
    
    <!-- Show Button to fetch data -->
    <button @click="fetchSummaryData">Show Summary</button>

    <!-- Bar Chart for Total Scores per Chapter -->
    <div v-if="barChartData.labels.length > 0">
      <h3>Total Scores per Chapter</h3>
      <Bar :data="barChartData" />
    </div>

    <!-- Pie Chart for Quiz Attempts -->
    <div v-if="pieChartData.labels.length > 0">
      <h3>Total Quiz Attempts</h3>
      <Pie :data="pieChartData" />
    </div>
    </div>
</template>

<script>
import NavbarComponent from '@/components/NavbarComponent.vue';
import { Bar, Pie } from 'vue-chartjs'
import { Chart as ChartJS, Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale, ArcElement } from 'chart.js'
import axios from 'axios'

// Register necessary Chart.js components
ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale, ArcElement)

export default {
  components: {
    NavbarComponent,
    Bar,
    Pie
  },
  data() {
    return {
      barChartData: {
        labels: [],
        datasets: [{
          label: 'Total Score',
          data: [],
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
        }],
      },
      pieChartData: {
        labels: [],
        datasets: [{
          data: [],
          backgroundColor: ['#FF5733', '#33FF57', '#3357FF', '#FF33A1', '#FFD433'],
        }],
      },
    }
  },
  methods: {
    async fetchSummaryData() {
      try {
        // API call to fetch the data
        const response = await axios.get('http://localhost:5000/api/admin/summary')
        const { bar_chart_data, pie_chart_data } = response.data

        // Update Bar Chart Data
        this.barChartData.labels = bar_chart_data.labels
        this.barChartData.datasets[0].data = bar_chart_data.data

        // Update Pie Chart Data
        this.pieChartData.labels = pie_chart_data.labels
        this.pieChartData.datasets[0].data = pie_chart_data.data
      } catch (error) {
        console.error("Error fetching admin summary data", error)
      }
    }
  },
}
</script>

<style scoped>
/* Styling for the charts */
canvas {
  max-width: 600px;
  margin: 20px auto;
} 

button {
  padding: 10px 20px;
  margin: 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}
</style>