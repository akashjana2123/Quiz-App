<template>
  <div>
    <h3>Subjects Overview</h3>
    <button class="btn btn-success btn-lg" @click="showAddSubjectModal">+ Add Subject</button>
    
    <div v-if="subjects.length === 0">
      <p>No subjects available. Add a new subject using the button above.</p>
    </div>
    
    <div v-else>
      <div v-for="subject in subjects" :key="subject.id" class="card mb-4">
        <div class="card-body">
          <h5 class="card-title">{{ subject.name }}</h5>
          <p class="card-text">{{ subject.description || 'No description provided' }}</p>
          <button class="btn btn-warning btn-sm" @click="showEditSubjectModal(subject)">Edit</button>
          <button class="btn btn-danger btn-sm ml-2" @click="deleteSubject(subject.id)">Delete</button>

          <!-- Chapter Component -->
          <ChapterComponent :subjectId="subject.id" />
        </div>
      </div>
    </div>

    <!-- Add/Edit Subject Modal -->
    <div class="modal fade" :class="{ 'show d-block': showModal }">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditing ? 'Edit Subject' : 'Add Subject' }}</h5>
            <button type="button" class="close" @click="closeModal">&times;</button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="handleSubject">
              <div class="form-group">
                <label for="name">Subject Name</label>
                <input type="text" class="form-control" id="name" v-model="form.name" required />
              </div>
              <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" v-model="form.description"></textarea>
              </div>
              <button class="btn btn-primary" type="submit">{{ isEditing ? 'Update' : 'Add' }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import ChapterComponent from './ChapterComponent.vue';

export default {
  components: { ChapterComponent },
  props: {
    subject: {
      type: Object,
      required: false, // Allow undefined subjects
      default: () => ({ id: null, name: '', description: '' }) // Default value
    }
  },
  data() {
    return {
      subjects: [],
      showModal: false,
      isEditing: false,
      form: { id: null, name: '', description: '' },
    };
  },
  methods: {
    async fetchSubjects() {
  try {
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };
    const response = await axios.get('http://localhost:5000/api/subject', { headers });
    this.subjects = response.data || []; // Ensure subjects is always an array
  } catch (error) {
    console.error('Error fetching subjects:', error.response?.data || error.message);
    this.subjects = []; // Fallback to an empty array
  }
},
    showAddSubjectModal() {
      this.form = { id: null, name: '', description: '' };
      this.isEditing = false;
      this.showModal = true;
    },
    showEditSubjectModal(subject) {
      this.form = { ...subject };
      this.isEditing = true;
      this.showModal = true;
    },
    async handleSubject() {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };

        if (this.isEditing) {
          await axios.put('http://localhost:5000/api/subject', {
            id: this.form.id,
            name: this.form.name,
            description: this.form.description
          }, { headers });
        } else {
          await axios.post('http://localhost:5000/api/subject', {
            name: this.form.name,
            description: this.form.description
          }, { headers });
        }

        this.closeModal();
        this.fetchSubjects();
      } catch (error) {
        console.error('Error submitting subject:', error.response?.data || error.message);
      }
    },
    async deleteSubject(id) {
      if (!confirm('Are you sure you want to delete this subject?')) return;
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        await axios.delete(`http://localhost:5000/api/subject/${id}`, { headers });
        this.fetchSubjects();
      } catch (error) {
        console.error('Error deleting subject:', error.response?.data || error.message);
      }
    },
    closeModal() {
      this.showModal = false;
    }
  },
  mounted() {
    this.fetchSubjects();
  }
};
</script>

<style scoped>
.card-body button {
  margin-right: 10px;
}
</style>