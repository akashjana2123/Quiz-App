<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <!-- Dynamic Title -->
      <router-link class="navbar-brand" to="/">{{ title || 'Quiz Portal' }}</router-link>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <router-link class="nav-link" :to="`/dashboard/${username}`">Home</router-link>
          </li>

          <!-- Admin Links -->
          <li class="nav-item" v-if="role === 'admin'">
            <router-link class="nav-link" :to="`/dashboard/${username}/quiz`">Quiz</router-link>
          </li>
          <li class="nav-item" v-if="role === 'admin'">
            <router-link class="nav-link" :to="`/dashboard/${username}/summary`">Summary</router-link>
          </li>

          <!-- Student Links -->
          <li class="nav-item" v-if="role === 'student'">
            <router-link class="nav-link" :to="`/dashboard/${username}/score`">Scores</router-link>
          </li>
          <li class="nav-item" v-if="role === 'student'">
            <router-link class="nav-link" :to="`/dashboard/${username}/summary/${userId}`">Summary</router-link>
          </li>

          <!-- CSV Export Buttons -->
          <li class="nav-item" v-if="role === 'admin'">
            <button class="nav-link btn btn-outline-primary" @click="downloadCSV('admin')">Download Admin CSV</button>
          </li>
          <li class="nav-item" v-if="role === 'student'">
            <button class="nav-link btn btn-outline-success" @click="downloadCSV('student')">Download Student CSV</button>
          </li>
        </ul>

        <!-- Logout & Profile Section -->
        <div class="d-flex align-items-center gap-2">
          <span v-if="username">Welcome, {{ username }}</span>
          <!-- Show Login/Signup on Home Page -->
          <template v-if="!username && $route.path === '/'">
            <button class="btn btn-primary" @click="login">Login</button>
            <button class="btn btn-outline-success" @click="signup">Signup</button>
          </template>
          <!-- Logout Button -->
          <button v-if="username" class="btn btn-outline-danger" @click="logout">Logout</button>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  props: {
    title: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      username: '',
      role: '',
      userId: null,
      token: '', // Store JWT token
    };
  },
  created() {
    const user = JSON.parse(localStorage.getItem('user'));
    this.token = localStorage.getItem('token');

    if (user) {
      this.username = user.username;
      this.role = user.role;
      this.userId = user.id;
    }
  },
  methods: {
    logout() {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      this.$router.push('/');
    },
    login() {
      this.$router.push('/login');
    },
    signup() {
      this.$router.push('/signup');
    },
    // async downloadCSV(type) {
    //   if (!this.token) {
    //     alert('You need to log in to download CSV.');
    //     return;
    //   }

    //   let url = `http://localhost:5000/exportcsv/1`;
    //   if (type === 'student') {
    //     url = `http://localhost:5000/exportcsv/${this.userId}`;
    //   }

    //   try {
    //     const response = await fetch(url, {
    //       method: 'POST',
    //       headers: {
    //         'Authorization': `Bearer ${this.token}`,
    //       },
    //     });

    //     if (!response.ok) {
    //       throw new Error('Failed to download CSV');
    //     }

    //     const blob = await response.blob();
    //     const downloadUrl = window.URL.createObjectURL(blob);
    //     const a = document.createElement('a');
    //     a.href = downloadUrl;
    //     a.download = `${type}-quiz-data.csv`;
    //     document.body.appendChild(a);
    //     a.click();
    //     a.remove();
    //   } catch (error) {
    //     console.error('Error downloading CSV:', error);
    //     alert('Error downloading CSV. Please try again.');
    //   }
    // },

    async downloadCSV(type) {
      if (!this.token) {
        alert('You need to log in to download CSV.');
        return;
      }

      let url = `http://localhost:5000/exportcsv/1`;
      if (type === 'student') {
        url = `http://localhost:5000/exportcsv/${this.userId}`;
      }

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.token}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to download CSV');
        }

        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = `${type}-quiz-data.csv`;  // Dynamic filename format
        document.body.appendChild(a);
        a.click();
        a.remove();
      } catch (error) {
        console.error('Error downloading CSV:', error);
        alert('Error downloading CSV. Please try again.');
      }
    },

  },
};
</script>

