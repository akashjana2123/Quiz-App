<template>
  <div>
    <NavbarComponent title="Admin Dashboard" class="sticky-top" />
    <h3>Quiz Management</h3>
    <button class="btn btn-success btn-lg" @click="showQuizModal">+ Add Quiz</button>

    <div v-if="quizzes.length === 0">
      <p>No quizzes available. Add a new quiz using the button above.</p>
    </div>

    <div v-else>
      <div v-for="quiz in quizzes" :key="quiz.id" class="card mb-4">
        <div class="card-body">
          <h5 class="card-title">{{ quiz.name }}</h5>
          <p class="card-text"><strong>Duration:</strong> {{ quiz.time_duration }} mins</p>
          <p class="card-text"><strong>Date:</strong> {{ formatDate(quiz.date_of_quiz) }}</p>
          <button class="btn btn-warning btn-sm" @click="editQuiz(quiz)">Edit</button>
          <button class="btn btn-danger btn-sm ml-2" @click="deleteQuiz(quiz.id)">Delete</button>
        </div>
      </div>
    </div>

    <!-- Add/Edit Quiz Modal -->
    <div class="modal fade" :class="{ 'show d-block': showModal }">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditing ? 'Edit Quiz' : 'Add Quiz' }}</h5>
            <button type="button" class="close" @click="closeModal">&times;</button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="handleQuiz">
              <div class="form-group">
                <label for="name">Quiz Name</label>
                <input type="text" class="form-control" id="name" v-model="form.name" required />
              </div>
              <div class="form-group">
                <label for="time_duration">Duration (in minutes)</label>
                <input type="number" class="form-control" id="time_duration" v-model="form.time_duration" required />
              </div>
              <div class="form-group">
                <label for="name">Remarks</label>
                <input type="text" class="form-control" id="name" v-model="form.remarks" />
              </div>

              <!-- Questions Table with Checkboxes -->
              <div class="form-group">
                <label>Questions</label>
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Select</th>
                      <th>Question</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="question in questions" :key="question.id">
                      <td>
                        <input type="checkbox" :value="question.id" v-model="selectedQuestions" />
                      </td>
                      <td>{{ question.question_statement }}</td> <!-- Updated from question.text -->
                    </tr>
                  </tbody>
                </table>
              </div>
              <button class="btn btn-primary" type="submit">{{ isEditing ? 'Update' : 'Add' }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NavbarComponent from '@/components/NavbarComponent.vue';
import axios from 'axios';

export default {
  components: { NavbarComponent },
  data() {
    return {
      quizzes: [],
      questions: [],
      selectedQuestions: [],
      showModal: false,
      isEditing: false,
      form: { id: null, name: '', time_duration: '', date_of_quiz: new Date().toISOString().split('T')[0],remarks:'' },
    };
  },
  methods: {
    async fetchQuizzes() { await this.fetchData('quiz', 'quizzes'); },
    async fetchQuestions() { await this.fetchData('question', 'questions'); },

    async fetchData(endpoint, target) {
      try {
        const response = await axios.get(`http://localhost:5000/api/${endpoint}`, { headers: this.getAuthHeaders() });
        this[target] = response.data || [];
      } catch (error) {
        console.error(`Error fetching ${endpoint}:`, error);
      }
    },

    async showQuizModal() {
      this.isEditing = false;
      this.resetForm();
      await this.fetchQuestions();
      this.showModal = true;
    },

    async editQuiz(quiz) {
  if (!quiz || !quiz.id) return;
  this.isEditing = true;
  this.form = { ...quiz };
  
  // Fetch all questions (to list them)
  await this.fetchQuestions();

  // Ensure that selectedQuestions contains only the associated question IDs
  this.selectedQuestions = quiz.questions ? quiz.questions.map(q => q.id) : [];

  this.showModal = true;
}
,

    async handleQuiz() {
  try {
    const method = this.isEditing ? 'put' : 'post';
    const url = this.isEditing ? `http://localhost:5000/api/quiz/${this.form.id}` : `http://localhost:5000/api/quiz`;

    await axios({
      method,
      url,
      data: {
        ...this.form,
        questions: this.selectedQuestions, // Updated question selection
      },
      headers: this.getAuthHeaders(),
    });

    this.closeModal();
    this.fetchQuizzes();
  } catch (error) {
    console.error('Error handling quiz:', error);
  }
},

    async deleteQuiz(id) {
      if (!confirm('Are you sure you want to delete this quiz?')) return;
      try {
        await axios.delete(`http://localhost:5000/api/quiz/${id}`, { headers: this.getAuthHeaders() });
        this.fetchQuizzes();
      } catch (error) {
        console.error('Error deleting quiz:', error);
      }
    },

    closeModal() {
      this.showModal = false;
      this.resetForm();
    },

    resetForm() {
      this.form = { id: null, name: '', time_duration: '', date_of_quiz: new Date().toISOString().split('T')[0] };
      this.selectedQuestions = [];
    },

    formatDate(dateStr) {
      return new Date(dateStr).toLocaleDateString();
    },

    getAuthHeaders() {
      const token = localStorage.getItem('token');
      return token ? { Authorization: `Bearer ${token}` } : {};
    }
  },
  mounted() {
    this.fetchQuizzes();
  }
};
</script>
