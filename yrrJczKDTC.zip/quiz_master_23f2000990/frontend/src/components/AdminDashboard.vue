<template>
  <div>
    <NavbarComponent title="Admin Dashboard" class="sticky-top" />
    <div class="container mt-5">
      <div class="student-container">
        <h2>Registered Students</h2>
        <div class="table-container">
          <table class="table table-striped">
            <thead class="sticky-header">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="student in students" :key="student.id">
                <td>{{ student.id }}</td>
                <td>{{ student.username }}</td>
                <td>{{ student.email }}</td>
                <td>{{ student.approved ? 'Approved' : 'Disapproved' }}</td>
                <td>
                  <button @click="toggleApproval(student)" class="btn" :class="student.approved ? 'btn-danger' : 'btn-success'">
                    {{ student.approved ? 'Disapprove' : 'Approve' }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <SubjectComponent />
    </div>
  </div>
</template>

<script>
import NavbarComponent from '@/components/NavbarComponent.vue';
import SubjectComponent from '@/components/SubjectComponent.vue';
import axios from 'axios';

export default {
  components: {
    NavbarComponent,
    SubjectComponent
  },
  data() {
    return {
      students: []
    };
  },
  methods: {
    async fetchStudents() {
  try {
    const token = localStorage.getItem("token"); // Retrieve token
    const response = await axios.get("http://localhost:5000/api/users", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    this.students = response.data.filter((user) => user.role === "student");
  } catch (error) {
    console.error("Error fetching students:", error);
  }
},

async toggleApproval(student) {
  try {
    const token = localStorage.getItem("token"); // Retrieve token
    await axios.post(
      "http://localhost:5000/api/approve-user",
      {
        user_id: student.id,
        approve: !student.approved,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    student.approved = !student.approved;
  } catch (error) {
    console.error("Error updating approval status:", error);
  }
},

  },
  mounted() {
    this.fetchStudents();
  }
};
</script>

<style scoped>
.container {
  margin-top: 20px;
}
.student-container {
  margin-bottom: 30px;
}
.table-container {
  max-height: 400px;
  overflow-y: auto;
  width: 100%;
}
.sticky-header {
  position: sticky;
  top: 0;
  background: white;
  z-index: 10;
}
.btn {
  min-width: 100px;
}
</style>
