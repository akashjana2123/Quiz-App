<template>
  <div class="question-container">
    <h5>Questions</h5>
    <button class="btn btn-primary btn-sm mb-2" @click="showAddQuestionModal">Add Question</button>
    <div class="table-responsive scrollable-table">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Question</th>
            <th>Options</th>
            <th>Correct Answer</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="question in questions" :key="question.id">
            <td>{{ question.id }}</td>
            <td>{{ question.question_statement }}</td>
            <td>
              <ul>
                <li>{{ question.option1 }}</li>
                <li>{{ question.option2 }}</li>
                <li v-if="question.option3">{{ question.option3 }}</li>
                <li v-if="question.option4">{{ question.option4 }}</li>
              </ul>
            </td>
            <td>{{ question[question.correct_option] }}</td>
            <td>
              <button class="btn btn-warning btn-sm" @click="editQuestion(question)">Edit</button>
              <button class="btn btn-danger btn-sm ml-2" @click="deleteQuestion(question.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Question Modal -->
    <div v-if="showModal" class="modal-overlay">
      <div class="modal-content">
        <h4>{{ isEditing ? 'Edit' : 'Add' }} Question</h4>
        <input v-model="formData.question_statement" placeholder="Question Statement" class="form-control mb-2" />
        <input v-model="formData.option1" placeholder="Option 1" class="form-control mb-2" />
        <input v-model="formData.option2" placeholder="Option 2" class="form-control mb-2" />
        <input v-model="formData.option3" placeholder="Option 3" class="form-control mb-2" />
        <input v-model="formData.option4" placeholder="Option 4" class="form-control mb-2" />
        <select v-model="formData.correct_option" class="form-control mb-2">
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
          <option value="option4">Option 4</option>
        </select>
        <button class="btn btn-success" @click="saveQuestion">Save</button>
        <button class="btn btn-secondary ml-2" @click="showModal = false">Cancel</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: ['quizId'],
  data() {
    return {
      questions: [],
      showModal: false,
      isEditing: false,
      formData: this.getDefaultFormData()
    };
  },
  watch: {
  quizId: {
    immediate: true,
    handler(newQuizId) {
      console.log("Received quizId:", newQuizId); // Debugging
      if (newQuizId) this.fetchQuestions(newQuizId);
    }
  }
},
  methods: {
    getDefaultFormData() {
  return {
    question_statement: '',
    option1: '',
    option2: '',
    option3: '',
    option4: '',
    correct_option: 'option1',
    quiz_id: this.quizId || null  // Ensure it's set dynamically
  };
},
    async fetchQuestions(quizId) {
  try {
    console.log("Fetching questions for quiz ID:", quizId); // Debugging
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };
    const response = await axios.get(`http://localhost:5000/api/question?quiz_id=${quizId}`, { headers });
    this.questions = response.data;
  } catch (error) {
    console.error("Error fetching questions:", error.response?.data || error.message);
  }
},
    showAddQuestionModal() {
      this.isEditing = false;
      this.formData = this.getDefaultFormData();
      this.showModal = true;
    },
    editQuestion(question) {
      this.isEditing = true;
      this.formData = { ...question };
      this.showModal = true;
    },
    async saveQuestion() {
  try {
    const url = this.isEditing
      ? `http://localhost:5000/api/question/${this.formData.id}`
      : 'http://localhost:5000/api/question';

    const method = this.isEditing ? axios.put : axios.post;
    const token = localStorage.getItem('token');
    const headers = { Authorization: `Bearer ${token}` };

    await method(url, this.formData, { headers });
    this.showModal = false;
    this.fetchQuestions(this.quizId);
  } catch (error) {
    console.error('Error saving question:', error);
    alert(error.response?.data?.message || 'Failed to save question');
  }
},
    async deleteQuestion(id) {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        await axios.delete(`http://localhost:5000/api/question/${id}`, { headers });
        this.fetchQuestions(this.quizId);
      } catch (error) {
        console.error('Error deleting question:', error.response?.data || error.message);
      }
    },
    openModal(editing = false, question = null) {
    this.isEditing = editing;
    this.formData = editing ? { ...question } : this.getDefaultFormData();
    this.showModal = true;
  }
  }
};
</script>

<style scoped>
.scrollable-table {
  max-height: 300px;
  overflow-y: auto;
}
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal-content {
  background: white;
  padding: 20px;
  border-radius: 5px;
  width: 400px;
}
</style>