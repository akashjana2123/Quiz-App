<template>
  <div>
    <NavbarComponent title="Student Dashboard" />
    <h1 class="text-center text-2xl font-bold mt-5">Student Dashboard</h1>
    <div class="container mx-auto p-5">
      <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr class="bg-gray-200">
            <th class="border px-4 py-2">Quiz Name</th>
            <th class="border px-4 py-2">Duration</th>
            <th class="border px-4 py-2">Date</th>
            <th class="border px-4 py-2">Total Questions</th>
            <th class="border px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="quiz in quizzes" :key="quiz.id">
            <td class="border px-4 py-2">{{ quiz.name }}</td>
            <td class="border px-4 py-2">{{ quiz.time_duration }}</td>
            <td class="border px-4 py-2">{{ quiz.date_of_quiz }}</td>
            <td class="border px-4 py-2">{{ quiz.question_count }}</td> <!-- Display question count here -->
            <td class="border px-4 py-2">
              <button @click="startQuiz(quiz.id)" class="btn bg-green-500 btn-success text-white px-3 py-1 rounded">
                Start
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import NavbarComponent from "./NavbarComponent.vue";
import axios from "axios";

export default {
  components: {
    NavbarComponent,
  },
  data() {
    return {
      username: '',
      quizzes: [], // Add quizzes array to store quiz data
    };
  },
  created() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      this.username = user.username;
    }
    this.fetchQuizzes(); // Fetch quizzes when component is created
  },
  methods: {
    // Fetch quizzes from the server
    async fetchQuizzes() {
      try {
        const token = localStorage.getItem("token"); // Get the token from localStorage
        const response = await axios.get("http://localhost:5000/api/quiz", {
          headers: { Authorization: `Bearer ${token}` },
        });
        this.quizzes = response.data; // Store the quiz data in the quizzes array
      } catch (error) {
        console.error("Error fetching quizzes:", error);
      }
    },
    startQuiz(quizId) {
      // When Start button is clicked, navigate to the quiz page
      const url = `/dashboard/${this.username}/quiz/${quizId}`;
      window.location.href = url; // Navigate to the quiz page
    }
  }
};
</script>

<style>
table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  border: 1px solid gray;
  padding: 8px;
  text-align: center;
}

th {
  background-color: #f4f4f4;
}
</style>
