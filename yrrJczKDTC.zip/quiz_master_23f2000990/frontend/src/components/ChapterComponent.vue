<template>
  <div>
    <h3>Chapters</h3>
    <button class="btn btn-success btn-lg" @click="showAddChapterModal">+ Add Chapter</button>

    <div v-if="chapters.length === 0">
      <p>No chapters available. Add a new chapter using the button above.</p>
    </div>

    <table v-else class="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Chapter Name</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="chapter in chapters" :key="chapter.id">
          <td>{{ chapter.id }}</td>
          <td>{{ chapter.name }}</td>
          <td>{{ chapter.description }}</td>
          <td>
            <button class="btn btn-warning btn-sm" @click="showEditChapterModal(chapter)">Edit</button>
            <button class="btn btn-danger btn-sm ml-2" @click="deleteChapter(chapter.id)">Delete</button>
            <button class="btn btn-primary btn-sm ml-2" @click="goToQuestions(chapter.id)">Questions</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Add/Edit Chapter Modal -->
    <div class="modal fade" :class="{ 'show d-block': showModal }">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">{{ isEditing ? 'Edit Chapter' : 'Add Chapter' }}</h5>
            <button type="button" class="close" @click="closeModal">&times;</button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="handleChapter">
              <div class="form-group">
                <label for="name">Chapter Name</label>
                <input type="text" class="form-control" id="name" v-model="form.name" required />
              </div>
              <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" id="description" v-model="form.description"></textarea>
              </div>
              <button class="btn btn-primary" type="submit">{{ isEditing ? 'Update' : 'Add' }}</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: ['subjectId'],
  data() {
    return {
      chapters: [],
      showModal: false,
      isEditing: false,
      form: { id: null, name: '', description: '' },
    };
  },
  methods: {
    async fetchChapters() {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        const response = await axios.get(`http://localhost:5000/api/chapter?subject_id=${this.subjectId}`, { headers });
        this.chapters = response.data;
      } catch (error) {
        console.error("Error fetching chapters:", error.response?.data || error.message);
      }
    },
    showAddChapterModal() {
      this.form = { id: null, name: '', description: '' };
      this.isEditing = false;
      this.showModal = true;
    },
    showEditChapterModal(chapter) {
      this.form = { ...chapter };
      this.isEditing = true;
      this.showModal = true;
    },
    async handleChapter() {
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };

        if (this.isEditing) {
          await axios.put(`http://localhost:5000/api/chapter/${this.form.id}`, {
            name: this.form.name,
            description: this.form.description
          }, { headers });
        } else {
          await axios.post('http://localhost:5000/api/chapter', {
            name: this.form.name,
            description: this.form.description,
            subject_id: this.subjectId
          }, { headers });
        }

        this.closeModal();
        this.fetchChapters();
      } catch (error) {
        console.error('Error submitting chapter:', error.response?.data || error.message);
      }
    },
    async deleteChapter(id) {
      if (!confirm('Are you sure you want to delete this chapter?')) return;
      try {
        const token = localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        await axios.delete(`http://localhost:5000/api/chapter/${id}`, { headers });
        this.fetchChapters();
      } catch (error) {
        console.error('Error deleting chapter:', error.response?.data || error.message);
      }
    },
    goToQuestions(chapterId) {
      this.$router.push({ name: 'QuestionsPage', params: { chapterId } });
    },
    closeModal() {
      this.showModal = false;
    }
  },
  mounted() {
    this.fetchChapters();
  }
};
</script>

<style scoped>
.scrollable-table {
  max-height: 300px;
  overflow-y: auto;
}
</style>