<template>
  <div class="background-container d-flex justify-content-center align-items-center vh-100">
    <div class="card glassmorphism p-5" style="max-width: 500px; width: 100%">
      <h2 class="text-center mb-4">Signup</h2>
      <form @submit.prevent="signupuser">
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" id="username" v-model="username" class="form-control" required />
        </div>

        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" id="email" v-model="email" class="form-control" required />
        </div>

        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input type="password" id="password" v-model="password" class="form-control" required />
        </div>

        <div class="mb-3">
          <label for="full_name" class="form-label">Full Name</label>
          <input type="text" id="full_name" v-model="full_name" class="form-control" required />
        </div>

        <div class="mb-3">
          <label for="dob" class="form-label">Date of Birth (YYYY-MM-DD)</label>
          <input type="date" id="dob" v-model="dob" class="form-control" />
        </div>

        <div class="mb-3">
          <label for="qualification" class="form-label">Qualification</label>
          <input type="text" id="qualification" v-model="qualification" class="form-control" />
        </div>

        <button type="submit" class="btn btn-primary w-100">Signup</button>
      </form>

      <div v-if="successMessage" class="alert alert-success mt-3" role="alert">
        {{ successMessage }}
      </div>
      <div v-if="errorMessage" class="alert alert-danger mt-3" role="alert">
        {{ errorMessage }}
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      username: '',
      email: '',
      password: '',
      full_name: '',
      qualification: '',
      dob: '',
      errorMessage: '',
      successMessage: '',
    };
  },
  methods: {
    async signupuser() {
      try {
        const response = await axios.post('http://localhost:5000/api/signup', {
          username: this.username,
          email: this.email,
          password: this.password,
          role: 'student',
          full_name: this.full_name,
          qualification: this.qualification,
          dob: this.dob || null,
        });
        this.successMessage = response.data.message || 'Signup successful! Redirecting to login...';

        setTimeout(() => {
          this.$router.push('/login');
        }, 2000);
      } catch (error) {
        this.errorMessage = error.response?.data?.message || 'Signup Failed. Please try again.';
      }
    }
  }
};
</script>

<style scoped>
.background-container {
  background: url('../assets/wallpaper.jpg') no-repeat center center/cover;
  height: 100vh;
  width: 100vw;
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.glassmorphism {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  padding: 30px;
}
</style>