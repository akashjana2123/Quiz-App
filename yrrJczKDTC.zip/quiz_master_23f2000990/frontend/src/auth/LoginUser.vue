<template>
  <div class="background-container d-flex justify-content-center align-items-center vh-100">
    <div class="card glassmorphism p-5" style="max-width: 500px; width: 100%">
      <h2 class="text-center mb-4">Login</h2>
      <form @submit.prevent="loginuser">
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" id="username" v-model="username" class="form-control" required />
        </div>

        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input type="password" id="password" v-model="password" class="form-control" required />
        </div>

        <button type="submit" class="btn btn-primary w-100">Login</button>

        <button type="button" class="btn btn-success w-100 mt-2" @click="redirectToSignup">
          Sign Up
        </button>
      </form>

      <div v-if="successMessage" class="alert alert-success mt-3" role="alert">
        {{ successMessage }}
      </div>
      <div v-if="errorMessage" class="alert alert-danger mt-3" role="alert">
        {{ errorMessage }}
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      username: "",
      password: "",
      errorMessage: "",
      successMessage: "",
    };
  },
  methods: {
    async loginuser() {
      try {
        const payload = {
          username: this.username,
          password: this.password,
        };

        const response = await axios.post(`http://localhost:5000/api/login`, payload);

        localStorage.setItem("token", response.data.access_token);
        localStorage.setItem("user", JSON.stringify(response.data.user));

        this.successMessage = "Login successful! Redirecting in a few seconds...";

        setTimeout(() => {
          this.$router.push(`/dashboard/${response.data.user.username}`);
        }, 2000);
      } catch (error) {
        this.errorMessage = error.response?.data?.message || "Login Failed. Please try again.";
      }
    },
    redirectToSignup() {
      this.$router.push(`/signup`);
    },
  },
};
</script>

<style scoped>
.background-container {
  background: url("../assets/wallpaper.jpg") no-repeat center center/cover;
  height: 100vh;
  width: 100vw;
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.glassmorphism {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
  padding: 30px;
}
</style>
